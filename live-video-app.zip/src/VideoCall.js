import React, { useEffect, useRef, useState } from "react";
import AgoraRTC from "agora-rtc-sdk-ng";

const APP_ID = "YOUR_AGORA_APP_ID";
const TOKEN = null;
const CHANNEL = "test";

const VideoCall = () => {
  const localVideoRef = useRef();
  const remoteVideoRef = useRef();
  const [client, setClient] = useState(null);

  useEffect(() => {
    const init = async () => {
      const client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
      setClient(client);

      client.on("user-published", async (user, mediaType) => {
        await client.subscribe(user, mediaType);
        if (mediaType === "video") {
          user.videoTrack.play(remoteVideoRef.current);
        }
        if (mediaType === "audio") {
          user.audioTrack.play();
        }
      });

      await client.join(APP_ID, CHANNEL, TOKEN, null);

      const localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack();
      const localVideoTrack = await AgoraRTC.createCameraVideoTrack();
      localVideoTrack.play(localVideoRef.current);

      await client.publish([localAudioTrack, localVideoTrack]);
      console.log("Local user published!");
    };

    init();

    return () => {
      client?.leave();
    };
  }, []);

  return (
    <div style={{ display: "flex", gap: "10px" }}>
      <div>
        <h3>Local Video</h3>
        <div
          ref={localVideoRef}
          style={{ width: "400px", height: "300px", backgroundColor: "black" }}
        />
      </div>
      <div>
        <h3>Remote Video</h3>
        <div
          ref={remoteVideoRef}
          style={{ width: "400px", height: "300px", backgroundColor: "black" }}
        />
      </div>
    </div>
  );
};

export default VideoCall;